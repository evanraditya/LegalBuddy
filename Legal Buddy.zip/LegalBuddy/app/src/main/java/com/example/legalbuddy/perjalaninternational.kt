package com.example.legalbuddy

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton

class perjalaninternational : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_perjalaninternational)
        val notifview = findViewById<ImageButton>(R.id.notifbtn)
        notifview.setOnClickListener{
            val Intent = Intent(this,notifikasi::class.java)
            startActivity(Intent)
        }

        val riwayatview = findViewById<ImageButton>(R.id.riwayatbtn)
        riwayatview.setOnClickListener {
            val Intent = Intent(this,Riwayat::class.java)
            startActivity(Intent)
        }

        val profilview = findViewById<ImageButton>(R.id.profilbtn)
        profilview.setOnClickListener {
            val Intent = Intent(this,Profil::class.java)
            startActivity(Intent)
        }

        val singapuraview = findViewById<Button>(R.id.singapura_btn)
        singapuraview.setOnClickListener {
            val Intent = Intent(this,singapura::class.java)
            startActivity(Intent)
        }
        val malayview = findViewById<Button>(R.id.malaysia_btn)
        malayview.setOnClickListener {
            val Intent = Intent(this,malaysia::class.java)
            startActivity(Intent)
        }
        val australiview = findViewById<Button>(R.id.australia_btn)
        australiview.setOnClickListener {
            val Intent = Intent(this,australia::class.java)
            startActivity(Intent)
        }
        val korselview = findViewById<Button>(R.id.korsel_btn)
        korselview.setOnClickListener {
            val Intent = Intent(this,korsel::class.java)
            startActivity(Intent)
        }
        val rrtview = findViewById<Button>(R.id.china_btn)
        rrtview.setOnClickListener {
            val Intent = Intent(this,RRT::class.java)
            startActivity(Intent)
        }
        val amerikaview = findViewById<Button>(R.id.amerika_btn)
        amerikaview.setOnClickListener {
            val Intent = Intent(this,amerikaserikat::class.java)
            startActivity(Intent)
        }
        val jepangview = findViewById<Button>(R.id.jepang_btn)
        jepangview.setOnClickListener {
            val Intent = Intent(this,jepang::class.java)
            startActivity(Intent)
        }
    }
}