package com.example.legalbuddy

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class malaysia : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_malaysia)

        val perjalananinter = findViewById<Button>(R.id.backbtn)
        perjalananinter.setOnClickListener {
            val Intent = Intent(this,perjalaninternational::class.java)
            startActivity(Intent)
        }
    }
}