package com.example.legalbuddy

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton

class admindokum : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admindokum)
        val notifview = findViewById<ImageButton>(R.id.notifbtn)
        notifview.setOnClickListener{
            val Intent = Intent(this,notifikasi::class.java)
            startActivity(Intent)
        }

        val riwayatview = findViewById<ImageButton>(R.id.riwayatbtn)
        riwayatview.setOnClickListener {
            val Intent = Intent(this,Riwayat::class.java)
            startActivity(Intent)
        }

        val profilview = findViewById<ImageButton>(R.id.profilbtn)
        profilview.setOnClickListener {
            val Intent = Intent(this,Profil::class.java)
            startActivity(Intent)
        }
        val perjalananinter = findViewById<Button>(R.id.dokperlune_btn)
        perjalananinter.setOnClickListener {
            val Intent = Intent(this,perjalaninternational::class.java)
            startActivity(Intent)
        }
    }
}