package com.example.legalbuddy

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton

class Homepage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_homepage)

        val notifview = findViewById<ImageButton>(R.id.notifbtn)
        notifview.setOnClickListener{
            val Intent = Intent(this,notifikasi::class.java)
            startActivity(Intent)
        }

        val riwayatview = findViewById<ImageButton>(R.id.riwayatbtn)
        riwayatview.setOnClickListener {
            val Intent = Intent(this,Riwayat::class.java)
            startActivity(Intent)
        }

        val profilview = findViewById<ImageButton>(R.id.profilbtn)
        profilview.setOnClickListener {
            val Intent = Intent(this,Profil::class.java)
            startActivity(Intent)
        }

        val admindokumenview = findViewById<ImageButton>(R.id.admindokbtn)
        admindokumenview.setOnClickListener {
            val Intent = Intent(this,admindokum::class.java)
            startActivity(Intent)
        }
    }
}